
using AspNETCoreWebApi7.Data.Contexts;
using Microsoft.EntityFrameworkCore;

namespace AspNETCoreWebApi7
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            //TODO: >>> check/refactor syntax of the following ..
            builder.Services.AddDbContext<AppDbContext>(options =>
            {
                options.UseSqlServer();
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();

            //TODO: quid app.UseDeveloperExceptionPage(); ???
            //TODO: quid API versioning ???
        }
    }
}