﻿
using AspNETCoreWebApi7.Data.Repositories;

namespace AspNETCoreWebApi7.Services
{
    public class TaskService : ITaskService
    {
        private readonly ITaskRepository _taskRepository;

        public TaskService(ITaskRepository taskRepository)
        { 
            _taskRepository = taskRepository;
        }

        public async Task<IEnumerable<Models.Task>> ListAsync()
        {
            return await _taskRepository.ListAsync();
        }
    }
}