﻿using AspNETCoreWebApi7.Data.Contexts;
using Microsoft.EntityFrameworkCore;

namespace AspNETCoreWebApi7.Data.Repositories
{
    public class TaskRepository : BaseRepository, ITaskRepository
    {
        public TaskRepository(AppDbContext context) : base(context)
        {
        }

        public async Task<IEnumerable<Models.Task>> ListAsync()
        {
            return await _context.Tasks.ToListAsync();
        }
    }
}