﻿namespace AspNETCoreWebApi7.Data.Repositories
{
    public interface ITaskRepository
    {
        Task<IEnumerable<Models.Task>> ListAsync();
    }
}