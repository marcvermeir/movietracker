﻿using AspNETCoreWebApi7.Data.Contexts;

namespace AspNETCoreWebApi7.Data.Repositories
{
    public abstract class BaseRepository
    {
        protected readonly AppDbContext _context;

        public BaseRepository(AppDbContext context) 
        { 
            _context = context;
        } 
    }
}
