﻿using Microsoft.EntityFrameworkCore;

namespace AspNETCoreWebApi7.Data.Contexts
{
    public class AppDbContext : DbContext
    {
        public DbSet<Models.Task> Tasks { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) 
        { 
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Models.Task>().ToTable(nameof(Models.Task));
            modelBuilder.Entity<Models.Task>().HasKey(t => t.Id);
            modelBuilder.Entity<Models.Task>().Property(t => t.Id).IsRequired().ValueGeneratedOnAdd();
            modelBuilder.Entity<Models.Task>().Property(t => t.Title).IsRequired().HasMaxLength(50);
            modelBuilder.Entity<Models.Task>().Property(t => t.Notes).HasMaxLength(255);

            modelBuilder.Entity<Models.Task>().HasData(
                new Models.Task() { Id = 1, Title = "Dummy Task 1", Notes = "" },
                new Models.Task() { Id = 2, Title = "Dummy Task 2", Notes = "" },
                new Models.Task() { Id = 3, Title = "Dummy Task 3", Notes = "" }
            );
        }
    }
}
