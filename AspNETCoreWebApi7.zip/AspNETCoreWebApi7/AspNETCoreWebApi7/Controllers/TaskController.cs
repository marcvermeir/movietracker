﻿using AspNETCoreWebApi7.Services;
using Microsoft.AspNetCore.Mvc;

namespace AspNETCoreWebApi7.Controllers
{
    [ApiController]
    [Route("/api/v1/[controller]")]
    public class TaskController : ControllerBase
    {
        private readonly ILogger<TaskController> _logger;
        private readonly ITaskService _taskService;

        public TaskController(ILogger<TaskController> logger, ITaskService taskService)
        {
            _logger = logger;
            _taskService = taskService;
        }

        // GET api/tasks
        [HttpGet]
        public async Task<IEnumerable<Models.Task>> GetAllAsync()
        {
            var tasks = await _taskService.ListAsync();
            
            return tasks;
        }

        /* 
        // GET api/tasks/5
        [HttpGet("{id}")]
        public ActionResult<Models.Task> Get(int id) => new Models.Task("xxx");

        // POST api/tasks
        [HttpPost]
        public void Post([FromBody] Models.Task task) { }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(long id, [FromBody] Models.Task task) { }

        // DELETE api/tasks/5
        [HttpDelete("{id}")]
        public void Delete(long id) { }
        */
    }
}
