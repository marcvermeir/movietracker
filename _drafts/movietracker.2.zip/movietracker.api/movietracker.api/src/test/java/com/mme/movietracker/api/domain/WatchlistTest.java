package com.mme.movietracker.api.domain;

import static org.junit.jupiter.api.Assertions.*;

class WatchlistTest {

}