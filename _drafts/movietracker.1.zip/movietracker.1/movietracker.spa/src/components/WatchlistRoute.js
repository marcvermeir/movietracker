import React, { Component } from 'react';
import RouteHeader from './RouteHeader';

class WatchlistRoute extends Component {

    /*
    constructor() {
        super();

    }
    */

    render() {
        return (
            <>
                <RouteHeader title="Watchlist of movies" />
            </>
        );
    }
}

export default WatchlistRoute;
