import React, { Component } from 'react';

class AddMovieRoute extends Component {

    /*
    constructor() {
        super();

    }
    */

    render() {
        return (
            <div>AddMovieRoute ..</div>
        );
    }
}

export default AddMovieRoute;