import React from 'react';

function Home() {
  return (
    <div>
        <h6>Home</h6>
    </div>
  );
}

export default Home;