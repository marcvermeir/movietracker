
export const CURRENCY_EUR = "EUR";