import API from './Api';

class ApiService {

    aFunc(params) {
        return API.get('...', params);
    }
}

export default new ApiService();