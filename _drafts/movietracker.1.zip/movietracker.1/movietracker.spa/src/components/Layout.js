import React from 'react';
import Footer from './Footer';
import { Container } from 'reactstrap';
import NavMenu from './NavBar';

function Layout(props) {
    return (
      <>
        <NavMenu />
        <Container fluid>
          {props.children}
        </Container>
        <Footer />
      </>
    );
  }
  
  export default Layout;