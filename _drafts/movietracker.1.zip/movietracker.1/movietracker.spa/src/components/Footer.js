import React from 'react';

function Footer() {
  return (
    <div>
        <p></p>
    </div>
  );
}

export default Footer;