import React from 'react';

function RouteHeader({ title }) {
  return (
    <div>
        <h6>{ title }</h6>
        <hr />
    </div>
  );
}

export default RouteHeader;