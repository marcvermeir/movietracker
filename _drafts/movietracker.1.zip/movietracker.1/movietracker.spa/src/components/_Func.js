import React from 'react';

function Func() {
  return (
    <div>
        <p>Func</p>
    </div>
  );
}

export default Func;