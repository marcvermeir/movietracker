import React from 'react';

function Watchlist() {
  return (
    <div>
        <h6>Watchlist ..</h6>
    </div>
  );
}

export default Watchlist;