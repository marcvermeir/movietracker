import React, {  createContext } from "react";

const AppContext = createContext({
  dummy: {}  
});

export class AppProvider extends React.Component {
    displayName = AppProvider.name;

    state = { dummy: {}
    }

    render() {
        return (
            <AppContext.Provider value={ this.state }>
                {this.props.children}
            </AppContext.Provider>
        )
    }
}

export const AppConsumer = AppContext.Consumer;
