import React from 'react';
import './App.css';
//// import 'primereact/resources/themes/nova-alt/theme.css';
//// import 'primereact/resources/primereact.min.css';
//// import 'primeicons/primeicons.css';
import { Route, Switch } from 'react-router-dom';
import { AppProvider, AppConsumer } from './components/Context';
import Layout from './components/Layout';
import WatchlistRoute from './components/WatchlistRoute';
import AddMovieRoute from './components/AddMovieRoute';

function App() {
  return (
    <div>
      {/* <ReactNotification */}

      <AppProvider>
        <Layout>
          <AppConsumer>
            {({ dummy }) => (
              <Switch>
                <Route exact path="/" component={ WatchlistRoute } />
                <Route path="/addmovie" component={ AddMovieRoute } />
              </Switch>
            )}
          </AppConsumer>
        </Layout>  
      </AppProvider>
    </div>
  );
}

export default App;