﻿namespace CleanArchitecture.Domain.Constants;

public abstract class Roles
{
    public const string Administrator = nameof(Administrator);
}