﻿global using CleanArchitecture.Web.AcceptanceTests.Pages;
global using BoDi;
global using FluentAssertions;
global using Microsoft.Playwright;
global using TechTalk.SpecFlow;